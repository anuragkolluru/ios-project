//
//  shoppingCartViewController.swift
//  Pattela_GroceryApp
//
//  Created by Student on 30/04/22.
//

import UIKit

class shoppingCartViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
 
    
   

    @IBOutlet weak var cartTotal: UILabel!
    

    @IBOutlet weak var shoppingCartTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        shoppingCartTableView.delegate = self
        shoppingCartTableView.dataSource = self
        
        cartTotal.text! = "\(cartPrice)"
        self.title = "Cart"
        
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = shoppingCartTableView.dequeueReusableCell(withIdentifier: "cartCell", for: indexPath)
        cell.textLabel?.text = items[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == UITableViewCell.EditingStyle.delete) {
            // delete data and row
            items.remove(at: indexPath.row)
            shoppingCartTableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    


}
