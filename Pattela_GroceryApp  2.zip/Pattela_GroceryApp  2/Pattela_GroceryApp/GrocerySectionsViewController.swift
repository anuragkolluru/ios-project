//
//  ViewController.swift
//  Pattela_GroceryApp
//
//  Created by Student on 4/12/22.
//

import UIKit

var itemlist = [String]()

var mdisplay = [GroceryItem]()

var imagearray = [GrocerySections ]()

class GrocerySectionsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var grocerySectionsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        title = "GrocerySections"
        grocerySectionsTableView.delegate = self
        grocerySectionsTableView.dataSource = self
        
        //Arrays Section data
        itemlist = [
                    
                    "Meat-Seafood",
                    "Burgers",
                    "Bevarges",
                    "Pizzas",
                    "sweets"
                    
                ]
                   // items info
                mdisplay = [
                    
                    GroceryItem(itemName: ["squid","rabbit","deer","fish","chicken"]),
                    GroceryItem(itemName: ["beaf","pork","cheese","chicken burger","fish burger"]),
                    GroceryItem(itemName: ["beer","rum","whiskey","wine","smoothies"]),
                    GroceryItem(itemName: ["pepperoni","margerita","chicken pizza","cheese pizza","mushroom pizza"]),
                    GroceryItem(itemName: ["gulabjam","rasmalai","choclate","brownie","bakalva"])
                    
                ]
                
                imagearray = [
                    
                    GrocerySections (
                    section: ["squid","rabbit","deer","fish","chicken"],
                    itemImage: [
                        "Squid are a type of cephalopods in the superorder Decapodiformes with elongated bodies, large eyes, eight arms and two tentacles. Like all other cephalopods, squid have a distinct head, bilateral symmetry, and a mantle.",
                        "Rabbit meat is a popular staple in countries around the world, even if it has not fully caught on in America. This is a delicious meat, and there are many health benefits with rabbit as part of your diet. ",
                        "Venison's health benefits are many. For starters, it's one of the leanest, heart-healthiest meats available — low in fat, high in protein and packed with zinc, haem iron, and vitamin B. It's also economical. “If you get two deer a year, you have enough food for the entire year,” Czerwony says.",
                        "Many species of fish are caught by humans and consumed as food in virtually all regions around the world. Fish has been an important dietary source of protein and other nutrients throughout human history.",
                        "Chicken is the most common type of poultry in the world. Owing to the relative ease and low cost of raising chickens—in comparison to mammals such as cattle or hogs—chicken meat and chicken eggs have become prevalent in numerous cuisines. "],
                    itemPrice: [ 10.0,15.0,16.0,18.0,20.0]
                    ),
                    
                    GrocerySections (
                    section: ["beaf","pork","cheese","chicken burger","fish bur"],
                    itemImage: [
                        " sandwich consisting of a cooked patty of ground or chopped beef, usually in a roll or bun, variously garnished; hamburger.",
                        "A hamburger (or burger for short) is a food consisting of fillings —usually a patty of ground meat, typically beef—placed inside a sliced bun or bread roll.",
                        "A cheeseburger is a hamburger topped with cheese. Traditionally, the slice of cheese is placed on top of the meat patty. ",
                        "A chicken sandwich is a sandwich that typically consists of boneless, skinless chicken breast or thigh served between slices of bread",
                        "A fish sandwich is, most generally, any kind of sandwich made with fish. The term is frequently used to describe food made with breaded, fried fish"],
                    itemPrice: [ 10.0,15.0,16.0,18.0,20.0]
                    ),
                    
                    GrocerySections (
                    section: ["beer","rum","whiskey","wine","smoothies"],
                    itemImage: [
                        "Beer is one of the world's oldest prepared alcoholic drinks. The earliest archaeological evidence of fermentation consists of 13,000-year-old residues of a beer.",
                        "Rum is a liquor made by fermenting then distilling sugarcane molasses or sugarcane juice. The distillate, a clear liquid, is usually aged in oak barrels.",
                        "Whisky or whiskey is a type of distilled alcoholic beverage made from fermented grain mash. Various grains (which may be malted)  ",
                        "Wine is an alcoholic drink typically made from fermented grapes. Yeast consumes the sugar in the grapes and converts it to ethanol and carbon dioxide.",
                        "A smoothie or smoothy is a drink made by puréeing fruits and/or vegetables in a blender. ... A smoothie often has a liquid base such as fruit juice, or dairy"],
                    itemPrice: [ 10.0,15.0,16.0,18.0,20.0]
                    ),
                    
                    GrocerySections (
                    section: ["pepperoni","margerita","chicken pizza","cheese pizza","mushroom pizza"],
                    itemImage: [
                        "Pepperoni is an American variety of spicy salami made from cured pork and beef seasoned with paprika or other chili pepper.Prior to cooking, pepperoni is characteristically soft, slightly smoky, and bright red. Thinly sliced pepperoni is one of the most popular pizza toppings in American pizzerias.",
                        "Pizza Margherita (more commonly known in English as Margherita pizza) is a typical Neapolitan pizza, made with San Marzano tomatoes, mozzarella cheese",
                        "Pizza (Italian: [ˈpittsa], Neapolitan: [ˈpittsə]) is a dish of Italian origin consisting of a usually round, flat base of leavened wheat-based dough topped with tomatoes, cheese, and often various other ingredients (such as anchovies, mushrooms, onions, olives, pineapple, meat, etc.), which is then baked at a high temperature, traditionally in a wood-fired oven.[1] A small pizza is sometimes called a pizzetta. A person who makes pizza is known as a pizzaiolo.",
                        "Pizza cheese encompasses several varieties and types of cheeses and dairy products that are designed and manufactured for use specifically on pizza. These include processed and modified cheese such as mozzarella-like processed cheeses and mozzarella variants. The term can also refer to any type of cheese suitable for use on pizza",
                        "Mellow Mushroom Pizza Bakers is an American pizza restaurant chain that was established in 1974 in Atlanta, Georgia as a single pizzeria."],
                    itemPrice: [ 10.0,15.0,16.0,18.0,20.0]
                    ),
                    
                    GrocerySections (
                    section: ["gulabjam","rasmalai","choclate","brownie","bakalva"],
                    itemImage: [
                        "Gulab jamun (also spelled gulaab jamun) is a milk-solid-based sweet, originating in the Indian subcontinent and a type of mithai popular in India, Pakistan",
                        "Ras malai consists of flattened balls of chhena soaked in malai (clotted cream) flavoured with cardamom. Milk is boiled and a bit of vinegar or lime juice.",
                        "Chocolate is a food product made from roasted and ground cacao pods, that is available as a liquid, solid or paste, on its own or as a flavoring agent.",
                        "A chocolate brownie or simply a brownie is a square or rectangular chocolate baked confection. Brownies come in a variety of forms and may be either fudgy.",
                        "Baklava is a layered pastry dessert made of filo pastry, filled with chopped nuts, and sweetened with syrup or honey. It was one of the most popular sweet."], itemPrice: [ 10.0,15.0,16.0,18.0,20.0])
                ]
            }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemlist.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        cell.textLabel?.text = itemlist[indexPath.row]
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let indexPath = self.grocerySectionsTableView.indexPathForSelectedRow
        var itemsarray : GroceryItem
        var displayimage : GrocerySections
        var description : GrocerySections
        
        itemsarray = mdisplay[indexPath!.row]
        displayimage = imagearray[indexPath!.row]
        description = imagearray[indexPath!.row]
        
        let identifier = segue.identifier
        if identifier == "itemsSegue" {
            let destination = segue.destination as! GroceryItemsViewController
            destination.productarray = itemsarray.itemName
            destination.infoarray = description.itemImage
            destination.priceArray = description.itemPrice
            destination.imagearray = displayimage.section
            destination.title = itemlist[indexPath!.row]
        }
    }
    
    }
