//
//  GroceryItemsViewController.swift
//  Pattela_GroceryApp
//
//  Created by Student on 4/12/22.
//

import UIKit


class GroceryItemsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productarray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = groceryItemsTableView.dequeueReusableCell(withIdentifier: "itemCell", for: indexPath)
        cell.textLabel?.text = productarray[indexPath.row]
        return cell
    }
    
    var productarray = [String]()
    var imagearray = [String]()
    var infoarray = [String]()
    var priceArray = [Double]()
    
    @IBOutlet weak var groceryItemsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        groceryItemsTableView.delegate = self
        groceryItemsTableView.dataSource = self
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let indexPath = self.groceryItemsTableView.indexPathForSelectedRow
        let identifier = segue.identifier
        if identifier == "itemInfoSegue" {
            let destination = segue.destination as! ItemInfoViewController
            destination.productInfo = infoarray[indexPath!.row]
            destination.image = UIImage(named: imagearray[indexPath!.row])!
            destination.title = productarray[indexPath!.row]
            destination.productPrice = priceArray[indexPath!.row]
            destination.itemTitle = productarray[indexPath!.row]

        }
    }
    
}
