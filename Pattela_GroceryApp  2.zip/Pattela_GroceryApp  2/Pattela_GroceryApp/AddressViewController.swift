//
//  AddressViewController.swift
//  Pattela_GroceryApp
//
//  Created by student on 5/1/22.
//

import UIKit

class AddressViewController: UIViewController {

    @IBOutlet weak var Addressline1: UITextField!
    
    @IBOutlet weak var Addressline2: UITextField!
    
    @IBOutlet weak var city: UITextField!
    
    @IBOutlet weak var state: UITextField!
    
    @IBOutlet weak var zipcode: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func Paybuttonclicked(_ sender: Any) {
        items = []
        cartPrice = 0.0
        
    }
    
}
