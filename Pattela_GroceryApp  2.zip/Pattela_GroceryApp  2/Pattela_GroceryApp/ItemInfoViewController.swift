//
//  ItemInfoViewController.swift
//  Pattela_GroceryApp
//
//  Created by Student on 4/12/22.
//

import UIKit

class ItemInfoViewController: UIViewController {
    
    var image = UIImage()
    var productInfo = String()
    var productPrice = 0.0
    var shoppingCartItem = [String]()
    var shoppingCartTotal = 0.0
    var itemTitle = ""
    
    @IBOutlet weak var itemImageViewOutlet: UIImageView!
    @IBOutlet weak var itemInfoOutlet: UITextView!
    
    //@IBOutlet weak var itemInfoOutlet: UILabel!
    @IBOutlet weak var getInfoOutlet: UIButton!
    
    
    @IBOutlet weak var itemPriceLabel: UILabel!
    
    @IBOutlet weak var addToCartClicked: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        getInfoOutlet.layer.cornerRadius = 15
        getInfoOutlet.clipsToBounds = true
        
        itemImageViewOutlet.image = image
        itemImageViewOutlet.layer.cornerRadius = 20
        itemImageViewOutlet.clipsToBounds = true
        
        
        itemInfoOutlet.text = ""
        itemPriceLabel.text! = "Price: \(productPrice)"
        
    }
    

    @IBAction func showItemInfoAction(_ sender: UIButton) {
        itemInfoOutlet.text = productInfo
        itemInfoOutlet.textColor = .darkText
        
    }
    
    @IBAction func addToCartClicked(_ sender: Any) {
        
        shoppingCartItem.append(itemTitle)
        items.append(itemTitle)
        cartPrice += productPrice
        
        shoppingCartTotal += productPrice
        
        
        
        
        
    }
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        let transition = segue.identifier
//        if transition == "cartSegue"
//        {
//            let destination = segue.destination as! shoppingCartViewController
//            destination.cartPrice = shoppingCartTotal
//
//            for item in shoppingCartItem{
//
//                print(item)
//                destination.items.append(item)
//            }
//
//
//        }
    
    
}


