//
//  ThankingViewController.swift
//  Pattela_GroceryApp
//
//  Created by srinivasa Bhumipalli on 5/1/22.
//

import UIKit

class ThankingViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        thankslabe.text! = "Your order is placed, thank you for shopping with us"

        // Do any additional setup after loading the view.
    }
    


    @IBOutlet weak var thankslabe: UILabel!
    
}
