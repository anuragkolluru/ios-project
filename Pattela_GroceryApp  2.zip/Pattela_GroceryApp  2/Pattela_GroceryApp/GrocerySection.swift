//
//  GrocerySection.swift
//  Pattela_GroceryApp
//
//  Created by Student on 4/12/22.
//

import Foundation
import UIKit

struct GroceryItem {
    var itemName: [String]
}

struct GrocerySections  {
    var section: [String]
    var itemImage: [String]
    var itemPrice: [Double]
}


var items = [String]()
var cartPrice = 0.0




